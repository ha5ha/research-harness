已在 Q-34844c27dfb4 中记录待审观察 F-9b33785801e2，并为主问题 Q-b948f194729b 保存阶段总结 S-e546436fdece。两者均为 proposed，阶段总结为 coverage partial，两个子问题与主问题均仍 open；没有审查通过、实验或新增样本。

复用来源是另一子问题 Q-d47a327e4f03 的 E-659e35343175，对应 results/shared.csv。该文件只有两个合成样本 a、b，baseline_error 分别为 2、4，等权均值为 3；它没有处理对照，不能回答处理是否改善误差。两个问题引用同一文件，不是独立复现，总唯一样本数仍为 2。

| 记录 | 含义 | 实际状态 |
|---|---|---|
| E-659e35343175 | 原子问题的共同基线证据 | 保持原记录 |
| E-bbde584cb4b4 | 新子问题下显式指向原证据的同源引用 | reference-only、未科学审查；并非新数据 |
| F-9b33785801e2 | 基于同源引用的基线观察 | proposed |
| S-e546436fdece | 主问题阶段总结，引用该观察 | proposed、partial |
| reports/stage_summary.md | 可读阶段报告及边界 | 已保存并被总结登记快照 |

直接用 E-659e35343175 作为兄弟问题的 evidence_ids 时，CLI 退出码 1，报“not in question subtree”。本次没有改工具、原输入或手工伪造跨问题关系，而是有限恢复：在新子问题登记同一源文件为 E-bbde584cb4b4，并在 description 中明确原 ID、原子问题、同文件同哈希以及“非新样本、非独立复现”；观察的 statement 与 limitations 也保留这条来源链。原 ID 的直接跨兄弟正式引用仍是工具未支持的部分，不能把替代引用说成 CLI 已支持这种边。

两条证据的文件和 SHA-256 完全相同：56437872fafa7a4dfac7beffa980b667f22efc32c12805929344a7b09b832c58，33 bytes。原证据 is_complete=false、scientific_acceptance=not_assessed；新增登记与干净哈希不能消除这些边界。没有模型、重复、抽样或误差定义信息，不能作稳定性、因果或泛化结论。

实际执行了初始 status/check、一次直接引用尝试、同源引用登记、待审观察登记、主问题总结登记及最终 check；最终 check 返回 ok true。已有输入及 skill 的哈希保留检查通过。没有 finding review、synthesis review、状态改写或事实晋级。

下一步建议是研究者明确处理对照、模型/协议与可区分的结果后，再决定是否授权新分析或实验。本次已完成允许的新增登记及阶段报告；待审状态和工具不支持的直接跨兄弟引用均明确保留。

