"""Offline analysis of existing synthetic rows; does not run predictions or alter inputs."""
from pathlib import Path
from collections import defaultdict
from itertools import product
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
plan = json.loads((ROOT / "research/PLAN.json").read_text(encoding="utf-8"))
with (ROOT / "results/predictions.csv").open(encoding="utf-8", newline="") as source:
    raw = list(csv.DictReader(source))
expected = set(product(plan["seeds"], plan["repeats"], plan["samples"]))
paired = []
seen = set()
for row in raw:
    key = (int(row["seed"]), int(row["repeat"]), row["sample"])
    if key in seen:
        raise ValueError(f"Duplicate identity: {key}")
    if key not in expected:
        raise ValueError(f"Unplanned identity: {key}")
    seen.add(key)
    target, baseline, prediction = [float(row[k]) for k in ("target", "source", "prediction")]
    if not all(math.isfinite(v) for v in (target, baseline, prediction)):
        raise ValueError(f"Nonfinite value: {key}")
    source_error, adapted_error = abs(baseline - target), abs(prediction - target)
    paired.append(dict(seed=key[0], repeat=key[1], sample=key[2],
                       target=target, source=baseline, prediction=prediction,
                       source_absolute_error=source_error, adapted_absolute_error=adapted_error,
                       delta_error=adapted_error-source_error))
if len(expected) != plan["expected_rows"]:
    raise ValueError("Plan expected_rows conflicts with its identity product")
by_repeat = defaultdict(list)
for row in paired:
    by_repeat[row["seed"], row["repeat"]].append(row)
repeat_summary = []
for seed, repeat in product(plan["seeds"], plan["repeats"]):
    rows = by_repeat[seed, repeat]
    n = len(rows)
    source_mae = sum(r["source_absolute_error"] for r in rows)/n if n else None
    adapted_mae = sum(r["adapted_absolute_error"] for r in rows)/n if n else None
    repeat_summary.append(dict(seed=seed, repeat=repeat, observed=n, planned=len(plan["samples"]),
                               complete=n==len(plan["samples"]),
                               source_mae_on_observed=source_mae, adapted_mae_on_observed=adapted_mae,
                               delta_mae_on_observed=adapted_mae-source_mae if n else None,
                               worsened=sum(r["delta_error"]>0 for r in rows),
                               improved=sum(r["delta_error"]<0 for r in rows)))
seed_summary = []
for seed in plan["seeds"]:
    complete = [r for r in repeat_summary if r["seed"]==seed and r["complete"]]
    deltas = [r["delta_mae_on_observed"] for r in complete]
    n = len(deltas)
    sd = math.sqrt(sum((d-sum(deltas)/n)**2 for d in deltas)/(n-1)) if n>1 else None
    seed_summary.append(dict(seed=seed, complete_repeats=n, planned_repeats=len(plan["repeats"]),
                             source_mae_complete_repeat_mean=sum(r["source_mae_on_observed"] for r in complete)/n if n else None,
                             adapted_mae_complete_repeat_mean=sum(r["adapted_mae_on_observed"] for r in complete)/n if n else None,
                             delta_mae_complete_repeat_mean=sum(deltas)/n if n else None,
                             between_repeat_delta_sample_sd=sd,
                             provisional=n!=len(plan["repeats"])))
def write_csv(name, rows):
    with (OUT/name).open("w", encoding="utf-8", newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
write_csv("paired_errors.csv", paired)
write_csv("repeat_summary.csv", repeat_summary)
write_csv("seed_summary.csv", seed_summary)
inputs = ["research/PLAN.json","research/CURRENT_STATE.yaml","research/PROJECT_SCOPE.md","research/question.md","results/predictions.csv","results/failure.log"]
result = dict(question_id="Q-native", statistical_unit="two synthetic samples a,b reused across seeds/repeats",
              aggregation=plan["aggregation"], expected_rows=len(expected), observed_rows=len(seen),
              unique_observed_samples=sorted({r["sample"] for r in paired}),
              missing=[dict(seed=s,repeat=r,sample=x) for s,r,x in sorted(expected-seen)],
              complete_repeats=sum(r["complete"] for r in repeat_summary),
              planned_repeats=len(plan["seeds"])*len(plan["repeats"]),
              repeat_summary=repeat_summary, seed_summary=seed_summary,
              overall_conclusion_eligible=seen==expected,
              overall_metric=None,
              limits=["No imputation; incomplete repeat excluded from seed repeat means",
                      "Rows, repeats and seeds are not additional independent samples",
                      "No model/checkpoint identity supplied; no independent test or causal inference"],
              provenance={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in inputs},
              analysis_code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/"analysis.json").write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps(result,indent=2,ensure_ascii=False))

