"""Derive paired offline metrics; never execute or impute experiments."""
import csv
import hashlib
import itertools
import json
import math
import statistics
from pathlib import Path

root = Path(__file__).resolve().parents[1]
plan = json.loads((root / "research/PLAN.json").read_text(encoding="utf-8-sig"))
source = root / "results/predictions.csv"
with source.open(encoding="utf-8-sig", newline="") as handle:
    raw = list(csv.DictReader(handle))
expected = set(itertools.product(plan["seeds"], plan["repeats"], plan["samples"]))
seen = set()
paired = []
for row in raw:
    key = (int(row["seed"]), int(row["repeat"]), row["sample"])
    assert key in expected and key not in seen, ("unexpected or duplicate row", key)
    seen.add(key)
    target, baseline, adapted = (float(row[x]) for x in ("target", "source", "prediction"))
    assert all(math.isfinite(x) for x in (target, baseline, adapted))
    before, after = abs(baseline - target), abs(adapted - target)
    paired.append(dict(seed=key[0], repeat=key[1], sample=key[2], source_error=before,
                       adapted_error=after, delta_error=after-before,
                       worsened=int(after > before)))
assert len(expected) == plan["expected_rows"]
repeat_metrics = []
for seed, repeat in itertools.product(plan["seeds"], plan["repeats"]):
    rows = [r for r in paired if (r["seed"], r["repeat"]) == (seed, repeat)]
    complete = {r["sample"] for r in rows} == set(plan["samples"])
    repeat_metrics.append(dict(seed=seed, repeat=repeat, n_samples=len(rows),
        planned_samples=len(plan["samples"]), complete=complete,
        source_mae=statistics.mean(r["source_error"] for r in rows),
        adapted_mae=statistics.mean(r["adapted_error"] for r in rows),
        delta_mae=statistics.mean(r["delta_error"] for r in rows),
        worsening_rate=statistics.mean(r["worsened"] for r in rows)))
seed_metrics = []
for seed in plan["seeds"]:
    rows = [r for r in repeat_metrics if r["seed"] == seed and r["complete"]]
    deltas = [r["delta_mae"] for r in rows]
    seed_metrics.append(dict(seed=seed, complete_repeats=len(rows),
        planned_repeats=len(plan["repeats"]),
        full_seed_coverage=len(rows) == len(plan["repeats"]),
        source_mae=statistics.mean(r["source_mae"] for r in rows),
        adapted_mae=statistics.mean(r["adapted_mae"] for r in rows),
        delta_mae=statistics.mean(deltas),
        worsening_rate=statistics.mean(r["worsening_rate"] for r in rows),
        delta_repeat_sample_sd=statistics.stdev(deltas) if len(deltas) > 1 else None))
missing = sorted(expected - seen)
assert missing == [(2, 2, "b")]
assert [r["delta_mae"] for r in repeat_metrics] == [-1, -1, 3, -2]
assert [r["complete"] for r in repeat_metrics] == [True, True, True, False]
assert [r["delta_mae"] for r in seed_metrics] == [-1, 3]
assert [r["complete_repeats"] for r in seed_metrics] == [2, 1]
out = root / "analysis"
for name, rows in (("paired_errors.csv", paired), ("repeat_metrics.csv", repeat_metrics),
                   ("seed_metrics.csv", seed_metrics)):
    with (out / name).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
summary = dict(source="results/predictions.csv", source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    planned_rows=len(expected), observed_rows=len(seen), missing=[list(x) for x in missing],
    unique_samples=sorted({r["sample"] for r in paired}),
    statistical_unit="two supplied synthetic samples; seed/repeat predictions are not extra subjects",
    overall_planned_conclusion_available=False,
    boundary="Offline development reanalysis, not a fresh experiment or independent test; incomplete repeat retained only as descriptive partial output",
    repeat_metrics=repeat_metrics, seed_metrics=seed_metrics)
(out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=2))
