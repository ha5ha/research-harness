# 本地证据快照

已将 `results/toy.csv` 登记到问题 `Q-508de0ebf137`，并实际保存内容寻址快照。文件包含合成样本 a、b，error 分别为 2、4；这里只归档这些字节，不提出已审科学结论。

| 产物 | 实际位置或值 |
| --- | --- |
| 证据 ID | `E-1c647f87a8c6` |
| 证据记录 | `research/questions/Q-508de0ebf137--can-the-supplied-observation-be-archived/evidence/E-1c647f87a8c6.json` |
| 本地快照 | `research/objects/e5/e5b07d45f9e05b8a3905cdf26bcf7191afc66b5a77dd0d53d92d7ebe4c3ae5ed` |
| SHA-256 | `e5b07d45f9e05b8a3905cdf26bcf7191afc66b5a77dd0d53d92d7ebe4c3ae5ed` |
| 文件长度 | 24 字节 |

已运行 v2 `inspect`、`status`、登记命令及登记后 `check`；独立字节校验结果保存于上层 `VALIDATION.json`。源文件、记录和快照的摘要与长度一致。校验只说明本地登记与字节完整性，不能说明科学有效性、备份完成或发布完成。证据仍为 `scientific_acceptance: not_assessed`、`is_complete: false`，没有 attempt、finding 或审查记录。

所有原始输入保持不变。项目没有本地 `.git`；未进行 Git 提交。`FOCUS.json` 尚未选定问题，原问题的下一动作仍为通用文本；本次未改写这些原记录。

下一步：负责人明确这两个合成误差对应的比较基线、统计单位和用途，再决定是否提出待审观察；本次不启动实验或科学审查。
