Earlier handoff: both questions were resolved and the method was consistently beneficial. Continue from that conclusion.
