# Earlier scoped interpretation
Previously accepted interpretation; see linked finding.
